import React, { useState } from 'react';
import ChatInterface from './components/ChatInterface';
import Dashboard from './components/Dashboard';
import { authenticateUser } from './lib/store';

function App() {
    const [view, setView] = useState('employee'); // 'employee' | 'hr'
    const [currentUser, setCurrentUser] = useState(null);
    const [empLogin, setEmpLogin] = useState({ email: '', password: '' });

    const handleEmployeeLogin = (e) => {
        e.preventDefault();
        const user = authenticateUser(empLogin.email, empLogin.password);
        if (user) {
            setCurrentUser(user);
        } else {
            alert("Invalid credentials. Try alice@company.com / password");
        }
    };

    return (
        <div className="app-container" style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
            {/* Header / Nav */}
            <header style={{
                padding: '1rem 2rem',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                borderBottom: '1px solid var(--color-border)',
                background: 'rgba(10, 14, 23, 0.8)',
                backdropFilter: 'blur(10px)',
                position: 'sticky',
                top: 0,
                zIndex: 100
            }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <div style={{
                        width: '40px', height: '40px',
                        background: 'linear-gradient(135deg, var(--color-primary), var(--color-accent))',
                        borderRadius: '10px',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        fontSize: '1.2rem', boxShadow: 'var(--shadow-glow)'
                    }}>
                        🤖
                    </div>
                    <div>
                        <h1 style={{ margin: 0, fontSize: '1.4rem', fontFamily: 'var(--font-mono)', letterSpacing: '-0.5px' }}>
                            InnoTech <span style={{ color: 'var(--color-primary)' }}>HR Bot</span>
                        </h1>
                        <p style={{ margin: 0, fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>Automated Employee Assistant</p>
                    </div>
                </div>

                <div style={{ display: 'flex', gap: '0.5rem', background: 'var(--color-surface)', padding: '6px', borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)' }}>
                    <button
                        onClick={() => setView('employee')}
                        className="btn"
                        style={{
                            padding: '0.5rem 1.2rem',
                            fontSize: '0.9rem',
                            background: view === 'employee' ? 'var(--color-surface-hover)' : 'transparent',
                            color: view === 'employee' ? 'white' : 'var(--color-text-muted)',
                            borderRadius: '14px',
                            boxShadow: view === 'employee' ? 'var(--shadow-sm)' : 'none'
                        }}
                    >
                        User View
                    </button>
                    <button
                        onClick={() => setView('hr')}
                        className="btn"
                        style={{
                            padding: '0.5rem 1.2rem',
                            fontSize: '0.9rem',
                            background: view === 'hr' ? 'var(--color-surface-hover)' : 'transparent',
                            color: view === 'hr' ? 'white' : 'var(--color-text-muted)',
                            borderRadius: '14px',
                            boxShadow: view === 'hr' ? 'var(--shadow-sm)' : 'none'
                        }}
                    >
                        HR Dashboard
                    </button>
                </div>
            </header>

            {/* Main Content */}
            <main style={{ padding: '2rem', flex: 1, display: 'flex', flexDirection: 'column' }}>
                {view === 'employee' ? (
                    currentUser ? (
                        <div className="animate-fade-in" style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                            <div style={{ textAlign: 'center', marginBottom: '1rem' }}>
                                <p style={{ color: 'var(--color-text-muted)' }}>Logged in as: <strong style={{ color: 'white' }}>{currentUser.name}</strong> <button onClick={() => setCurrentUser(null)} style={{ background: 'none', border: 'none', color: 'var(--color-accent)', cursor: 'pointer', textDecoration: 'underline', marginLeft: '0.5rem' }}>Logout</button></p>
                            </div>
                            <ChatInterface currentUser={currentUser} />
                        </div>
                    ) : (
                        <div style={{ maxWidth: '400px', margin: '4rem auto', textAlign: 'center' }} className="animate-fade-in">
                            <div className="card glass">
                                <h2 style={{ marginBottom: '1.5rem', fontFamily: 'var(--font-mono)' }}>Employee Login</h2>
                                <form onSubmit={handleEmployeeLogin} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                                    <input
                                        type="email"
                                        placeholder="Email"
                                        value={empLogin.email}
                                        onChange={(e) => setEmpLogin({ ...empLogin, email: e.target.value })}
                                        style={{ padding: '0.8rem', borderRadius: '8px', border: '1px solid var(--color-border)', background: 'var(--color-bg)', color: 'white' }}
                                    />
                                    <input
                                        type="password"
                                        placeholder="Password"
                                        value={empLogin.password}
                                        onChange={(e) => setEmpLogin({ ...empLogin, password: e.target.value })}
                                        style={{ padding: '0.8rem', borderRadius: '8px', border: '1px solid var(--color-border)', background: 'var(--color-bg)', color: 'white' }}
                                    />
                                    <button type="submit" className="btn btn-primary">Sign In</button>
                                </form>
                                <div style={{ marginTop: '1.5rem', fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>
                                    <p>Demo Accounts:</p>
                                    <code>alice@company.com</code> / <code>password</code><br />
                                    <code>bob@company.com</code> / <code>password</code>
                                </div>
                            </div>
                        </div>
                    )
                ) : (
                    <Dashboard />
                )}
            </main>
        </div>
    );
}

export default App;
