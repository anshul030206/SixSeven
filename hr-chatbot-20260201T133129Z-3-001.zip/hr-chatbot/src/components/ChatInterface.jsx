import React, { useState, useEffect, useRef } from 'react';
import { saveRequest, getUnreadMessagesForUser, markMessagesAsRead } from '../lib/store';
import { getGroqResponse } from '../lib/groq';

const INTENTS = [
    { id: 'leave', label: '🏖️ Request Leave' },
    { id: 'issue', label: '💼 Personal/Professional Issue' },
    { id: 'harassment', label: '⚠️ Report Harassment', danger: true },
    { id: 'escalate', label: '🔔 Escalate to HR', danger: false },
];

const BOT_AVATAR = "🤖";
const USER_AVATAR = "👤";

const ChatInterface = ({ currentUser }) => {
    // Initial State
    const [messages, setMessages] = useState([]);
    const [isTyping, setIsTyping] = useState(false);
    const [inputText, setInputText] = useState("");
    const [viewState, setViewState] = useState('idle'); // idle, date_picker, awaiting_input, offering_solution, settings
    const [activeIntent, setActiveIntent] = useState(null);
    const [dates, setDates] = useState({ start: '', end: '' });

    // API Key State
    const [apiKey, setApiKey] = useState(localStorage.getItem('groq_api_key') || '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');
    const [showSettings, setShowSettings] = useState(false);

    const messagesEndRef = useRef(null);

    // Initialize chat
    useEffect(() => {
        setMessages([
            {
                id: 'welcome',
                sender: 'bot',
                text: `Hi ${currentUser.name}! I'm your HR assistant. How can I help you today? Choose an option from the sidebar or type your request.`,
                timestamp: new Date().toISOString()
            },
        ]);
        setViewState('idle');
        setActiveIntent(null);
    }, [currentUser]);

    // Polling
    useEffect(() => {
        const pollInterval = setInterval(() => {
            const unread = getUnreadMessagesForUser(currentUser.id);
            if (unread.length > 0) {
                const newMsgs = unread.map(m => ({
                    id: m.id,
                    sender: 'bot',
                    text: `📨 Message from HR: ${m.message}`,
                    timestamp: m.timestamp,
                    isSystem: true
                }));
                setMessages(prev => [...prev, ...newMsgs]);
                markMessagesAsRead(unread.map(m => m.id));
            }
        }, 3000);
        return () => clearInterval(pollInterval);
    }, [currentUser]);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };
    useEffect(scrollToBottom, [messages, isTyping, viewState]);

    const addMessage = (sender, text, extra = {}) => {
        const msg = {
            id: Date.now(),
            sender,
            text,
            timestamp: new Date().toISOString(),
            ...extra
        };
        setMessages(prev => [...prev, msg]);
        return msg;
    };

    const handleBotResponse = (text, delay = 1000, callback) => {
        setIsTyping(true);
        setTimeout(() => {
            setIsTyping(false);
            addMessage('bot', text);
            if (callback) callback();
        }, delay);
    };

    const handleIntentClick = (intent) => {
        if (viewState !== 'idle') return;

        setActiveIntent(intent.id);
        addMessage('user', intent.label);

        switch (intent.id) {
            case 'leave':
                handleBotResponse("I'll help you request time off. Please select your leave dates below.", 800, () => {
                    setViewState('date_picker');
                });
                break;
            case 'issue':
                // Gemini check
                if (!apiKey) {
                    handleBotResponse("To provide smart assistance, I need a Gemini API Key. Please click the Settings (⚙️) icon to add it, or I can just escalate this request directly.");
                    setViewState('awaiting_input');
                } else {
                    handleBotResponse("I'm connected to the AI knowledge base. Please describe your issue, and I'll do my best to help!");
                    setViewState('awaiting_gemini');
                }
                break;
            case 'harassment':
                handleBotResponse("I'm sorry you're experiencing this. Your safety is our priority. Please provide details about the incident. This will be escalated immediately and handled with complete confidentiality.");
                setViewState('awaiting_input');
                break;
            case 'escalate':
                handleBotResponse("I'll escalate your request to the HR team. Please describe what you need help with.");
                setViewState('awaiting_input');
                break;
            default:
                setViewState('idle');
        }
    };

    const handleGeminiInteraction = async (text) => {
        setIsTyping(true);
        const response = await getGroqResponse(apiKey, text, messages.filter(m => !m.isSystem));
        setIsTyping(false);

        // Check for escalation tag
        if (response.includes("[ESCALATE]")) {
            const cleanResponse = response.replace("[ESCALATE]", "").trim();
            addMessage('bot', cleanResponse || "I think this is best handled by a human specialist.");

            handleBotResponse("Would you like me to escalate this ticket to HR now?", 500, () => {
                setViewState('offering_solution');
            });
        } else {
            addMessage('bot', response);
            // stay in awaiting_gemini state to allow continued conversation
        }
    };

    const handleTextSubmit = (e) => {
        e.preventDefault();
        if (!inputText.trim()) return;

        const text = inputText;
        setInputText("");
        addMessage('user', text);

        if (viewState === 'awaiting_gemini') {
            handleGeminiInteraction(text);
            return;
        }

        if (viewState === 'awaiting_input') {
            const req = saveRequest({
                type: INTENTS.find(i => i.id === activeIntent)?.label || 'General Inquiry',
                message: text,
                escalated: activeIntent === 'escalate' || activeIntent === 'harassment'
            }, currentUser);

            handleBotResponse(`Thank you. Your request has been submitted to HR. Reference: #${req.id.toString().slice(-6)}`);
            setViewState('idle');
            setActiveIntent(null);
        } else {
            handleBotResponse("Please choose an option from the sidebar to start a specific request.");
        }
    };

    const handleSolutionResponse = (solved) => {
        if (solved) {
            addMessage('user', "Yes, that helped.");
            handleBotResponse("Great! I'm glad I could help. Let me know if you need anything else.");
        } else {
            addMessage('user', "No, I need to talk to someone.");
            const req = saveRequest({
                type: 'Personal/Professional Issue',
                message: "Escalated: AI could not resolve issue.",
                escalated: true
            }, currentUser);
            handleBotResponse(`Understood. I've escalated this to HR immediately. Reference: #${req.id.toString().slice(-6)}`);
        }
        setViewState('idle');
        setActiveIntent(null);
    };

    const handleDateSubmit = () => {
        if (!dates.start || !dates.end) return;

        const start = new Date(dates.start);
        const end = new Date(dates.end);

        if (end < start) {
            handleBotResponse("The end date cannot be before the start date. Please try again.");
            return;
        }

        const diffTime = Math.abs(end - start);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;

        const req = saveRequest({
            type: 'Leave Request',
            message: `Leave Requested: ${dates.start} to ${dates.end} (${diffDays} days)`,
            escalated: false,
            dates: { start: dates.start, end: dates.end }
        }, currentUser);

        setViewState('idle');
        setDates({ start: '', end: '' });
        setActiveIntent(null);

        handleBotResponse(`Your leave request has been submitted for ${diffDays} days. HR will review and respond within 24 hours. Reference: #${req.id.toString().slice(-6)}`);
    };

    const calculateDays = () => {
        if (!dates.start || !dates.end) return null;
        const start = new Date(dates.start);
        const end = new Date(dates.end);
        if (end < start) return "Invalid Range";
        return Math.ceil(Math.abs(end - start) / (1000 * 60 * 60 * 24)) + 1;
    };

    const saveApiKey = (key) => {
        setApiKey(key);
        localStorage.setItem('groq_api_key', key);
        setShowSettings(false);
    };

    return (
        <div style={{ display: 'flex', gap: '2rem', height: '600px', maxWidth: '1200px', margin: '0 auto', position: 'relative' }}>
            {/* Quick Actions Sidebar */}
            <div className="card glass hide-mobile" style={{ width: '300px', padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                    <h3 style={{ margin: 0, fontFamily: 'var(--font-mono)', fontSize: '0.9rem', color: 'var(--color-text-muted)', textTransform: 'uppercase' }}>
                        Quick Actions
                    </h3>
                    <button onClick={() => setShowSettings(true)} className="btn btn-ghost" style={{ padding: '4px' }} title="AI Settings">
                        ⚙️
                    </button>
                </div>
                {INTENTS.map(intent => (
                    <button
                        key={intent.id}
                        onClick={() => handleIntentClick(intent)}
                        disabled={viewState !== 'idle'}
                        className="btn"
                        style={{
                            justifyContent: 'flex-start',
                            background: activeIntent === intent.id ? 'var(--color-primary)' : 'rgba(255,255,255,0.03)',
                            border: intent.danger ? '1px solid rgba(239, 68, 68, 0.3)' : '1px solid rgba(255,255,255,0.05)',
                            color: intent.danger && activeIntent !== intent.id ? 'var(--color-danger)' : 'var(--color-text)',
                            opacity: viewState !== 'idle' && activeIntent !== intent.id ? 0.5 : 1
                        }}
                    >
                        {intent.label}
                    </button>
                ))}

                {viewState === 'awaiting_gemini' && (
                    <button
                        onClick={() => {
                            setViewState('idle');
                            setActiveIntent(null);
                            addMessage('bot', "Conversation ended. How else can I help?");
                        }}
                        className="btn btn-ghost"
                        style={{ marginTop: 'auto', border: '1px solid var(--color-border)', justifyContent: 'center' }}
                    >
                        End Chat
                    </button>
                )}
            </div>

            {/* Main Chat Area */}
            <div className="card glass" style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
                <div style={{ flex: 1, overflowY: 'auto', padding: '2rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                    {messages.map((msg, idx) => (
                        <div key={idx} className={`animate-slide-up`} style={{
                            alignSelf: msg.sender === 'bot' ? 'flex-start' : 'flex-end',
                            maxWidth: '75%',
                            display: 'flex',
                            gap: '1rem',
                            flexDirection: msg.sender === 'user' ? 'row-reverse' : 'row'
                        }}>
                            <div style={{
                                width: '36px', height: '36px',
                                borderRadius: '50%',
                                background: msg.sender === 'bot' ? 'var(--color-primary)' : 'var(--color-surface-light)',
                                display: 'flex', alignItems: 'center', justifyContent: 'center',
                                fontSize: '1.2rem',
                                flexShrink: 0,
                                boxShadow: 'var(--shadow-sm)'
                            }}>
                                {msg.sender === 'bot' ? BOT_AVATAR : USER_AVATAR}
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
                                <div style={{
                                    background: msg.sender === 'bot' ? 'var(--color-surface-light)' : 'linear-gradient(135deg, var(--color-primary), var(--color-primary-dark))',
                                    padding: '1rem 1.5rem',
                                    borderRadius: '18px',
                                    borderTopLeftRadius: msg.sender === 'bot' ? '4px' : '18px',
                                    borderTopRightRadius: msg.sender === 'user' ? '4px' : '18px',
                                    color: 'var(--color-text)',
                                    lineHeight: '1.6',
                                    whiteSpace: 'pre-wrap',
                                    boxShadow: 'var(--shadow-sm)',
                                    position: 'relative'
                                }}>
                                    {msg.text}
                                </div>
                                <span style={{
                                    fontSize: '0.7rem',
                                    color: 'var(--color-text-muted)',
                                    alignSelf: msg.sender === 'user' ? 'flex-end' : 'flex-start',
                                    padding: '0 0.5rem'
                                }}>
                                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>
                            </div>
                        </div>
                    ))}

                    {/* INTERACTION ZONES */}
                    {viewState === 'date_picker' && (
                        <div className="animate-slide-up" style={{ alignSelf: 'flex-start', marginLeft: '3.5rem', width: '300px' }}>
                            <div style={{
                                background: 'var(--color-surface)',
                                padding: '1.5rem',
                                borderRadius: 'var(--radius-md)',
                                border: '1px solid var(--color-border)',
                                display: 'flex', flexDirection: 'column', gap: '1rem'
                            }}>
                                <div>
                                    <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--color-text-muted)', marginBottom: '0.5rem' }}>Start Date</label>
                                    <input
                                        type="date"
                                        value={dates.start}
                                        onChange={(e) => setDates({ ...dates, start: e.target.value })}
                                        style={{ width: '100%', padding: '0.5rem', background: 'var(--color-bg)', border: '1px solid var(--color-border)', borderRadius: '6px', color: 'white' }}
                                    />
                                </div>
                                <div>
                                    <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--color-text-muted)', marginBottom: '0.5rem' }}>End Date</label>
                                    <input
                                        type="date"
                                        value={dates.end}
                                        onChange={(e) => setDates({ ...dates, end: e.target.value })}
                                        style={{ width: '100%', padding: '0.5rem', background: 'var(--color-bg)', border: '1px solid var(--color-border)', borderRadius: '6px', color: 'white' }}
                                    />
                                </div>

                                {calculateDays() && (
                                    <div style={{ fontSize: '0.9rem', color: 'var(--color-accent)', textAlign: 'center' }}>
                                        Duration: <strong>{calculateDays()} days</strong>
                                    </div>
                                )}

                                <button
                                    onClick={handleDateSubmit}
                                    className="btn btn-primary"
                                    disabled={!dates.start || !dates.end || calculateDays() === "Invalid Range"}
                                    style={{ width: '100%', marginTop: '0.5rem' }}
                                >
                                    Submit Request
                                </button>
                            </div>
                        </div>
                    )}

                    {viewState === 'offering_solution' && (
                        <div className="animate-slide-up" style={{ alignSelf: 'flex-start', marginLeft: '3.5rem', display: 'flex', gap: '1rem' }}>
                            <button onClick={() => handleSolutionResponse(true)} className="btn" style={{ background: 'var(--color-success)', color: 'black' }}>
                                ✓ Yes, Issue Solved
                            </button>
                            <button onClick={() => handleSolutionResponse(false)} className="btn" style={{ background: 'rgba(239, 68, 68, 0.2)', color: 'var(--color-danger)', border: '1px solid var(--color-danger)' }}>
                                ⚠️ No, Escalate to HR
                            </button>
                        </div>
                    )}

                    {isTyping && (
                        <div className="animate-fade-in" style={{ alignSelf: 'flex-start', marginLeft: '3.5rem', display: 'flex', gap: '4px', padding: '1rem' }}>
                            <span className="dot" style={{ animationDelay: '0s' }}>•</span>
                            <span className="dot" style={{ animationDelay: '0.2s' }}>•</span>
                            <span className="dot" style={{ animationDelay: '0.4s' }}>•</span>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>

                {/* Input Area */}
                <form onSubmit={handleTextSubmit} style={{ padding: '1.5rem', background: 'var(--color-surface-light)', borderTop: '1px solid var(--color-border)' }}>
                    <div style={{ display: 'flex', gap: '1rem' }}>
                        <textarea
                            value={inputText}
                            onChange={(e) => setInputText(e.target.value)}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter' && !e.shiftKey) {
                                    e.preventDefault();
                                    handleTextSubmit(e);
                                }
                            }}
                            placeholder={viewState === 'awaiting_input' || viewState === 'awaiting_gemini' ? "Type here..." : "Type your message here..."}
                            disabled={viewState === 'date_picker' || viewState === 'offering_solution'}
                            style={{
                                flex: 1,
                                background: 'var(--color-bg)',
                                border: '1px solid var(--color-border)',
                                borderRadius: '12px',
                                padding: '1rem',
                                color: 'white',
                                resize: 'none',
                                height: '24px',
                                fontFamily: 'inherit',
                                fontSize: '0.95rem'
                            }}
                        />
                        <button
                            type="submit"
                            disabled={!inputText.trim() || (viewState !== 'awaiting_input' && viewState !== 'awaiting_gemini')}
                            className="btn btn-primary"
                            style={{
                                borderRadius: '12px',
                                width: '50px',
                                opacity: (!inputText.trim() || (viewState !== 'awaiting_input' && viewState !== 'awaiting_gemini')) ? 0.5 : 1
                            }}
                        >
                            ➤
                        </button>
                    </div>
                </form>
            </div>

            {/* Settings Modal */}
            {showSettings && (
                <div style={{
                    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
                    background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(4px)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000
                }}>
                    <div className="card glass" style={{ width: '400px', padding: '2rem' }}>
                        <h3 style={{ margin: '0 0 1rem 0' }}>AI Settings</h3>
                        <p style={{ fontSize: '0.9rem', color: 'var(--color-text-muted)', marginBottom: '1rem' }}>
                            Enter your Groq API Key to enable smart AI responses.
                        </p>
                        <input
                            type="password"
                            placeholder="Groq API Key (gsk_...)"
                            defaultValue={apiKey}
                            onChange={(e) => setApiKey(e.target.value)} // Temporary
                            style={{ width: '100%', padding: '0.8rem', background: 'var(--color-bg)', border: '1px solid var(--color-border)', borderRadius: '8px', color: 'white', marginBottom: '1rem' }}
                        />
                        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.5rem' }}>
                            <button onClick={() => setShowSettings(false)} className="btn btn-ghost">Cancel</button>
                            <button onClick={(e) => saveApiKey(e.target.previousSibling.previousSibling.value)} className="btn btn-primary">Save Key</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ChatInterface;
