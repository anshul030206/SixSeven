import React, { useState, useEffect } from 'react';
import { getAllRequests, getStats, updateRequestStatus, sendHRMessage, clearStore } from '../lib/store';

const Dashboard = () => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [loginData, setLoginData] = useState({ email: '', password: '' });

    // Auth State
    if (!isAuthenticated) {
        return (
            <div style={{ maxWidth: '400px', margin: '4rem auto', textAlign: 'center' }}>
                <div className="card glass">
                    <h2 style={{ marginBottom: '1.5rem', fontFamily: 'var(--font-mono)' }}>HR Portal Login</h2>
                    <form onSubmit={(e) => {
                        e.preventDefault();
                        if (loginData.email === 'hr@company.com' && loginData.password === 'hr123') {
                            setIsAuthenticated(true);
                        } else {
                            alert('Invalid Credentials');
                        }
                    }} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                        <input
                            type="email"
                            placeholder="Email"
                            value={loginData.email}
                            onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                            style={{ padding: '0.8rem', borderRadius: '8px', border: '1px solid var(--color-border)', background: 'var(--color-bg)', color: 'white' }}
                        />
                        <input
                            type="password"
                            placeholder="Password"
                            value={loginData.password}
                            onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                            style={{ padding: '0.8rem', borderRadius: '8px', border: '1px solid var(--color-border)', background: 'var(--color-bg)', color: 'white' }}
                        />
                        <button type="submit" className="btn btn-primary">Sign In to Dashboard</button>
                    </form>
                    <div style={{ marginTop: '1.5rem', fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>
                        <p>Demo Credentials:</p>
                        <code>hr@company.com</code> / <code>hr123</code>
                    </div>
                </div>
            </div>
        );
    }

    return <DashboardContent onLogout={() => setIsAuthenticated(false)} />;
};

const DashboardContent = ({ onLogout }) => {
    const [stats, setStats] = useState(getStats());
    const [requests, setRequests] = useState(getAllRequests());
    const [messageModal, setMessageModal] = useState({ open: false, requestId: null, text: '' });

    const refreshData = () => {
        setStats(getStats());
        setRequests(getAllRequests());
    };

    useEffect(() => {
        refreshData();
        const interval = setInterval(refreshData, 3000);
        return () => clearInterval(interval);
    }, []);

    const handleAction = (id, action) => {
        if (action === 'approve') {
            updateRequestStatus(id, 'approved');
        } else if (action === 'reject') {
            updateRequestStatus(id, 'rejected');
        }
        refreshData();
    };

    const handleSendMessage = () => {
        if (messageModal.text.trim()) {
            sendHRMessage(messageModal.requestId, messageModal.text);
            setMessageModal({ open: false, requestId: null, text: '' });
            alert("Message sent to user.");
        }
    };

    const handleClearSystem = () => {
        if (confirm("Are you sure you want to wipe all system data? This cannot be undone.")) {
            clearStore();
            refreshData();
        }
    };

    return (
        <div className="animate-fade-in" style={{ maxWidth: '1200px', margin: '0 auto', paddingBottom: '4rem' }}>
            {/* Header / Stats */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                <div>
                    <h2 style={{ fontSize: '1.8rem', marginBottom: '0.5rem' }}>Overview</h2>
                    <p style={{ color: 'var(--color-text-muted)' }}>Welcome back, HR Admin.</p>
                </div>
                <div style={{ display: 'flex', gap: '1rem' }}>
                    <button className="btn btn-ghost" onClick={handleClearSystem} style={{ color: 'var(--color-danger)' }}>⚠ Reset System</button>
                    <button className="btn btn-ghost" onClick={onLogout}>Logout</button>
                </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '1.5rem', marginBottom: '3rem' }}>
                <StatCard label="Total Requests" value={stats.total} icon="📊" />
                <StatCard label="Pending" value={stats.pending} icon="⏳" color="var(--color-warning)" />
                <StatCard label="Escalated" value={stats.escalated} icon="⚠️" color="var(--color-danger)" />
                <StatCard label="Leave" value={stats.leave} icon="🏖️" />
                <StatCard label="Issues" value={stats.issues} icon="💼" />
                <StatCard label="Harassment" value={stats.harassment} icon="🛑" color="var(--color-danger)" />
            </div>

            {/* Request List */}
            <h3 style={{ marginBottom: '1.5rem', borderBottom: '1px solid var(--color-border)', paddingBottom: '1rem' }}>Recent Requests</h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                {requests.length === 0 ? (
                    <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--color-text-muted)', border: '1px dashed var(--color-border)', borderRadius: '12px' }}>
                        No requests found.
                    </div>
                ) : (
                    requests.map(req => (
                        <div key={req.id} className="card" style={{
                            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                            borderLeft: req.escalated ? '4px solid var(--color-danger)' : '4px solid var(--color-primary)',
                            padding: '1.5rem'
                        }}>
                            <div style={{ flex: 1 }}>
                                <div style={{ display: 'flex', gap: '0.8rem', alignItems: 'center', marginBottom: '0.5rem' }}>
                                    <span style={{
                                        fontSize: '0.75rem', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: '0.5px',
                                        color: req.escalated ? 'var(--color-danger)' : 'var(--color-accent)'
                                    }}>
                                        {req.type}
                                    </span>
                                    {req.status === 'pending' && <span style={{ fontSize: '0.7rem', background: 'var(--color-warning)', color: 'black', padding: '2px 8px', borderRadius: '4px', fontWeight: 'bold' }}>PENDING</span>}
                                    {req.status === 'approved' && <span style={{ fontSize: '0.7rem', background: 'var(--color-success)', color: 'black', padding: '2px 8px', borderRadius: '4px', fontWeight: 'bold' }}>APPROVED</span>}
                                    {req.status === 'rejected' && <span style={{ fontSize: '0.7rem', background: 'rgba(255,255,255,0.2)', color: 'white', padding: '2px 8px', borderRadius: '4px' }}>REJECTED</span>}
                                    <span style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>
                                        from <strong style={{ color: 'white' }}>{req.userName || 'Anonymous'}</strong> (#{req.id.toString().slice(-4)})
                                    </span>
                                </div>
                                <p style={{ margin: '0 0 0.5rem 0', fontSize: '1.1rem' }}>{req.message}</p>
                                <div style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>
                                    {new Date(req.timestamp).toLocaleString()}
                                </div>
                            </div>

                            {req.status === 'pending' && (
                                <div style={{ display: 'flex', gap: '0.5rem', marginLeft: '2rem' }}>
                                    <button onClick={() => handleAction(req.id, 'approve')} className="btn" style={{ background: 'var(--color-success)', color: '#002200', padding: '0.5rem 1rem', fontSize: '0.8rem' }}>
                                        ✓ Approve
                                    </button>
                                    <button onClick={() => handleAction(req.id, 'reject')} className="btn" style={{ background: 'rgba(255,50,50,0.2)', color: 'var(--color-danger)', padding: '0.5rem 1rem', fontSize: '0.8rem', border: '1px solid var(--color-danger)' }}>
                                        ✗ Reject
                                    </button>
                                    <button onClick={() => setMessageModal({ open: true, requestId: req.id, text: '' })} className="btn btn-ghost" style={{ fontSize: '0.8rem' }}>
                                        📨 Message
                                    </button>
                                </div>
                            )}
                            {req.status !== 'pending' && (
                                <button onClick={() => setMessageModal({ open: true, requestId: req.id, text: '' })} className="btn btn-ghost" style={{ marginLeft: '2rem', fontSize: '0.8rem' }}>
                                    📨 Follow up
                                </button>
                            )}
                        </div>
                    ))
                )}
            </div>

            {/* Message Modal */}
            {messageModal.open && (
                <div style={{
                    position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
                    background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(4px)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000
                }}>
                    <div className="card" style={{ width: '400px', background: 'var(--color-surface)' }}>
                        <h3>Send Message to User</h3>
                        <textarea
                            value={messageModal.text}
                            onChange={(e) => setMessageModal({ ...messageModal, text: e.target.value })}
                            placeholder="Type a message..."
                            style={{ width: '100%', height: '120px', padding: '1rem', background: 'var(--color-bg)', border: '1px solid var(--color-border)', borderRadius: '8px', color: 'white', marginBottom: '1rem' }}
                        />
                        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.5rem' }}>
                            <button onClick={() => setMessageModal({ open: false, requestId: null, text: '' })} className="btn btn-ghost">Cancel</button>
                            <button onClick={handleSendMessage} className="btn btn-primary">Send Message</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

const StatCard = ({ label, value, icon, color }) => (
    <div className="card" style={{
        padding: '1.5rem',
        display: 'flex', flexDirection: 'column', gap: '0.5rem',
        borderTop: color ? `4px solid ${color}` : `4px solid var(--color-primary)`,
        background: 'var(--color-surface)'
    }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '1.5rem' }}>
            <span style={{ fontWeight: 'bold' }}>{value}</span>
            <span>{icon}</span>
        </div>
        <span style={{ fontSize: '0.85rem', color: 'var(--color-text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>{label}</span>
    </div>
);

export default Dashboard;
